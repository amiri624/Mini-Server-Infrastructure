# Mini-Server-Infrastructure

## Step one

```bash
sudo apt update
sudo apt install docker.io docker-compose -y
```

## Then

```bash
sudo systemctl start docker
sudo systemctl enable docker
```

## Test

```bash
docker run hello-world
```

## Step two

```bash
docker run -d -p 8080:80 nginx
```

# Phase 2

```bash
mkdir my-project
cd my-project
nano docker-compose.yml
```
## Than Content 
```bash
version: '3'

services:
  web:
    image: nginx
    ports:
      - "8080:80"
```
## Execution

```bash
docker-compose up -d
```

# Phase 3: Adding the Database

```bash
version: '3'

services:
  web:
    image: nginx
    ports:
      - "8080:80"

  db:
    image: mysql
    environment:
      MYSQL_ROOT_PASSWORD: root
```

# Phase 5 Backup

```bash
vim backup.sh
```

```bash
#!/bin/bash
tar -czf backup.tar.gz .
```

## Execution

```bash
chmod +x backup.sh
./backup.sh
```

